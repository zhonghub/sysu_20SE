package info.gridworld.maze;

import info.gridworld.actor.Actor;
import info.gridworld.actor.Bug;
import info.gridworld.actor.Flower;
import info.gridworld.actor.Rock;
import info.gridworld.grid.*;
import info.gridworld.grid.Location;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;
import java.util.Stack;

/**
 * A <code>MazeBug</code> can find its way in a maze. <br />
 * The implementation of this class is testable on the AP CS A and AB exams.
 */
public class MazeBug extends Bug {
	/*
	 * last,前一个位置，即栈顶crossLocation.peak()
	 * isEnd,判断是否找到终点
	 * crossLocation,深度优先沿当前路线上的Location的栈
	 * stepCout,总步数
	 * times，每个方向上移动的概率计数数组
	 * reached，使用HashSet来记录已经到达过的Locaton、
	 * nowDirection，记录当前位置可移动的方向
	 * outTime,记录输出次数，只能输出1次：要么到达终点；要么不存在路径
	 */
	public Location last;
	public boolean isEnd = false;
	public Stack<Location> crossLocation = new Stack<Location>();
	public Integer stepCount = 0;
	public final int TURNS = 90;
	public int[] times = new int[4];
	public HashSet<Location> reached = new HashSet<Location>();
	public ArrayList<Integer> nowDirection;
	private int outTime = 1;

	/*
	 * 初始化：
	 * 颜色为GREEN
	 * 概率计数数组times
	 */
	public MazeBug() {
		setColor(Color.GREEN);
		last = new Location(0, 0);
		for (int i = 0; i < 4; ++i) {
			times[i] = 1;
		}
	}

	/**
	 * move() if not reach destination
	 * else stop and out stepCout and depth
	 */
	@Override
	public void act() {
		if (outTime < 1) {
			return;
		}
		else {
			if (!isEnd) {
				move();
				stepCount++;
				return;
			} else {
				System.out.println("stepCout= " + stepCount);
				System.out.println("depth= " + crossLocation.size());
				outTime--;
				return;
			}
		}
	}


	/*
	 * move to a not reached Location
	 * if there it is
	 * else back to last Location
	 * 
	 */
	@Override
	public void move() {
		Location loc = getNextStep();
		if (loc != null) {
			crossLocation.push(getLocation());
			moveTo(loc);
		} else {
			moveTo(crossLocation.pop());
			return;
		}
	}

	/*
	 * 移动到一个位置newLocation
	 * 如果该位置未到达过：给概率计数数组times[]中对应项+1
	 * 否则-1
	 */
	@Override
	public void moveTo(Location newLocation) {
		Grid<Actor> gr = getGrid();
		if (gr == null)
			return;
		if (getLocation().equals(newLocation)) {
			return;
		}
		if (gr.isValid(newLocation)) {
			last = getLocation();
			super.moveTo(newLocation);
			setDirection(last.getDirectionToward(getLocation()));
			if (reached.contains(newLocation)) {
				times[(int) (getDirection() / 90)] -= 1;
				if (times[(int) (getDirection() / 90)] < 1) {
					times[(int) (getDirection() / 90)] = 1;
				}
			} else {
				reached.add(newLocation);
				times[(int) (getDirection() / 90)] += 1;
			}
		} else {
			removeSelfFromGrid();
		}
		Flower flower = new Flower(getColor());
		flower.putSelfInGrid(gr, last);
	}

	/*
	 * 获取下一步可移动到的所有位置
	 * (深度优先只含未到达过的可达Location)
	 * 
	 * @return ArrayList<Location>
	 */
	public ArrayList<Location> getValidLocations() {
		ArrayList<Location> locs = new ArrayList<Location>();
		Grid<Actor> gr = getGrid();
		Location loc = getLocation();
		ArrayList<Integer> now = new ArrayList<Integer>();
		for (int i = 0; i < 4; ++i) {
			Location neighborLoc = loc.getAdjacentLocation(i * TURNS);
			if (!gr.isValid(neighborLoc)) {
				continue;
			}
			Actor next = gr.get(neighborLoc);
			if (!reached.contains(neighborLoc)) {
				if (next == null || (next instanceof Rock && next.getColor().equals(Color.RED))) {
					locs.add(neighborLoc);
					now.add(i);
				}
			}
		}
		nowDirection = now;
		return locs;
	}

	/*
	 * 选择下一步移动的位置，如果包含终点之间返回终点。
	 * return locs.get(0); 普通深度优先
	 * return locs.get(getNextDirection(locs)); 增加概率的深度优先
	 * 
	 * @return Location
	 */
	public Location getNextStep() {
		ArrayList<Location> locs = getValidLocations();
		if (locs.size() != 0) {
			Grid<Actor> gr = getGrid();
			for (Location x : locs) {
				Actor next = gr.get(x);
				if (next instanceof Rock && next.getColor().equals(Color.RED)) {
					isEnd = true;
					// moveTo(x);
					return x;
				}
			}
			// return locs.get(0);
			return locs.get(getNextDirection(locs));
		} else {
			return null;
		}
	}

	/*
	 * 按概率选择方向
	 * 返回的是选中的Location在ArrayList<Location>中的索引
	 * 
	 * return int
	 */
	public int getNextDirection(ArrayList<Location> locs) {
		int sum = 0;
		for (int x : nowDirection) {
			sum += times[x];
		}
		double pnum = (new Random().nextDouble()) * sum;
		int p1 = 0;
		int p2 = times[nowDirection.get(0)];
		for (int i = 0; i < nowDirection.size() - 1; ++i) {
			if (pnum >= p1 && pnum <= p2) {
				// return nowDirection.get(i);
				return i;
			}
			p1 += times[nowDirection.get(i)];
			p1 += times[nowDirection.get(i + 1)];

		}
		return nowDirection.size() - 1;
	}
}
