## Readme.md

### 文件目录

```
 ├── Mazebug
 │   └── project 	// 项目文件夹
 |		  └── info      // 源文件目录
 │   	  └── *.txt 	// 测试迷宫文件
 │   └── maze 		// 我写的源码
 │   	  └── info.gridworld.maze.MazeBug.java  
 │   	  └── info.gridworld.maze.MazeBugRunner.java 
 │   └── sonar-project.properties // Sonar 代码评估配置文件
 ├── README.md
```



### 代码运行方式

(这里已将MazeBug.java和MazeBugRunner.java 放到包info.gridworld.maze下）

在project目录下运行指令：

```


javac -classpath .:./info ./info/gridworld/maze/*.java && java -classpath .:./info info/gridworld/maze/MazeBugRunner




```

