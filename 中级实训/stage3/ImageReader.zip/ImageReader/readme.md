## Readme.md

### 文件目录

```
 ├── ImageReader
 │   └── bmptest 	// 测试图片文件夹
 │   └── lib		// 项目依赖jar包目录
 │   └── src 		// 项目源码
 │   	  └── ImplementImageIO.java 
 │   	  └── ImplementImageProcessor.java
 │   	  └── MyRGBImageFilter.java
 │   	  └── ImageReaderRunner.java    
 │   	  └── ImageProcessorTest.java //junit测试文件
 │   └── classes 				  // 编译的.class目录
 │   └── build.xml				  // ant 构建文件
 │   └── sonar-project.properties // Sonar 代码评估配置文件
 ├── README.md
```



### 运行方式

在当前目录下运行：

```

ant compile && java -classpath .:classes:lib/* ImageReaderRunner

 或
 
javac -d classes -classpath .:lib/* ./src/*.java && java -classpath .:classes:lib/* ImageReaderRunner

```



### junit测试

当前目录下运行：



ant test



结果图片：

在目录bmptest/myResult下生成两个测试图片的RGB三个通道的bmp图像以及灰度图像。
