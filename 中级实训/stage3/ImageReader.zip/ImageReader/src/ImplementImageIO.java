import java.io.FileInputStream;
import java.awt.*;
import java.io.*;
import java.awt.image.*;
import javax.imageio.*;
import java.util.logging.*;

import imagereader.*;

public class ImplementImageIO implements IImageIO {
    private static Logger LOGGER = Logger.getLogger(ImplementImageIO.class.toString());

    /**
     * 总长度为54的byte数组：
     * 位图头 0-13
     * 位图信息 14-53
     */
    byte[] bitmapFileHeader = new byte[54];

    /*
     * int width 18-21图片宽度（像素为单位）
     * height 22-25图片高度（像素为单位）
     * pixelNum 28-29,保存每个像素的位数，它是图像的颜色深度。常用值是1、4、8（灰阶）和24（彩色）
     * skipNum 每一行的空字节补齐位数，每次以1字节作为读取的单位
     */
    int width = 0;
    int height = 0;
    int pixelNum = 0;
    int skipNum = 0;

    /**
     * myRead implements from IImageIO
     * 
     * @param filePath
     * @return image
     */
    public Image myRead(String filePath) {
        FileInputStream in = null;
        try {
            in = new FileInputStream(filePath);
            if (in == null) {
                throw new IOException();
            }
            if (in.read(bitmapFileHeader) != 54) {
                throw new IllegalArgumentException("Bitmap Hearder is error!");
            }

            width = getInt(bitmapFileHeader, 18, 4);
            height = getInt(bitmapFileHeader, 22, 4);
            pixelNum = getInt(bitmapFileHeader, 28, 2);
            // 计算补齐字节数，每次以1字节作为读取的单位
            skipNum = ((32 - (width * pixelNum) % 32) / 8) % 4;

            int[] imageArray = new int[height * width];
            for (int i = height - 1; i >= 0; i--) {
                for (int j = 0; j < width;) {
                    int b = in.read();
                    if (pixelNum == 24) {
                        int g = in.read();
                        int r = in.read();
                        Color color = new Color(r, g, b);
                        imageArray[i * width + j] = color.getRGB();
                        ++j;
                    } else if (pixelNum == 8) {
                        Color color = new Color(b, b, b);
                        imageArray[i * width + j] = color.getRGB();
                        ++j;
                    } else if (pixelNum == 4) {
                        int[] bs = new int[2];
                        bs[0] = b >> 4;
                        bs[1] = b & 0xF;
                        for (int k = 0; k < 2; ++k) {
                            Color color = new Color(bs[k], bs[k], bs[k]);
                            imageArray[i * width + j] = color.getRGB();
                            ++j;
                            if (j >= width) {
                                break;
                            }
                        }
                    } else if (pixelNum == 1) {
                        int bs8 = b & 0xFF;
                        int[] bs = new int[8];
                        for (int k = 7; k >= 0; --k) {
                            bs[k] = bs8 & 1;
                            bs8 = bs8 >> 1;
                        }
                        for (int k = 0; k < 8; ++k) {
                            Color color = new Color(bs[k], bs[k], bs[k]);
                            imageArray[i * width + j] = color.getRGB();
                            ++j;
                            if (j >= width) {
                                break;
                            }
                        }
                    }
                }
                if (skipNum != 0) {
                    long buffer = in.skip(skipNum);
                }
            }
            in.close();
            ImageProducer producer = new MemoryImageSource(width, height, imageArray, 0, width);
            Image image = Toolkit.getDefaultToolkit().createImage(producer);
            return image;
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "myRead", e);
        }
        return null;
    }

    /**
     * myWrite implements from IImageIO
     * 
     * @param image
     * @param filePath
     * @return store image data to filePath
     */
    public Image myWrite(Image image, String filePath) {
        try {
            BufferedImage buffer;
            int w = image.getWidth(null);
            int h = image.getHeight(null);

            if (pixelNum == 24) {
                buffer = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
            } else {
                buffer = new BufferedImage(w, h, BufferedImage.TYPE_BYTE_GRAY);
            }

            Graphics2D graphics = buffer.createGraphics();
            graphics.drawImage(image, 0, 0, null);

            File file = new File(filePath);
            ImageIO.write(buffer, "bmp", file);

        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "myWrite", e);
        }
        return null;
    }

    /*
     * 从字节数组中获取一个int整数,不足4字节补0
     * 
     * @param bytes0 目标字节数组
     * 
     * @param start 起始位置
     * 
     * @param len 长度
     * 
     * @return 一个int型整数
     */
    private int getInt(byte[] bytes0, int start, int len) {
        byte[] b = new byte[4];
        for (int i = 0; i < len; ++i) {
            b[i] = bytes0[i + start];
        }
        for (int i = 0; i < 4 - len; ++i) {
            b[len + i] = 0;
        }
        return (b[3] & 0xff << 24) | (b[2] & 0xff) << 16 | (b[1] & 0xff) << 8 | (b[0] & 0xff);
    }

}
