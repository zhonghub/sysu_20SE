import java.awt.*;
import java.awt.Image;
import java.awt.image.*;
import java.util.logging.*;

import imagereader.*;

public class ImplementImageProcessor implements IImageProcessor {
    private static Logger LOGGER = Logger.getLogger(ImplementImageProcessor.class.toString());

    /**
     * showChanelR
     * 
     * @param sourceImage
     * @return the red channel image of the source
     */
    public Image showChanelR(Image sourceImage) {
        try {
            ImageProducer producer = new FilteredImageSource(sourceImage.getSource(),
                    new MyRGBImageFilter(MyRGBImageFilter.RED));
            return Toolkit.getDefaultToolkit().createImage(producer);
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "error", e);
        }
        return null;
    }

    /**
     * showChanelG
     * 
     * @param sourceImage
     * @return the green channel image of the source
     */
    public Image showChanelG(Image sourceImage) {
        try {
            ImageProducer producer = new FilteredImageSource(sourceImage.getSource(),
                    new MyRGBImageFilter(MyRGBImageFilter.GREEN));
            return Toolkit.getDefaultToolkit().createImage(producer);
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "error", e);
        }
        return null;
    }

    /**
     * showChanelB
     * 
     * @param sourceImage
     * @return the blue channel image of the source
     */
    public Image showChanelB(Image sourceImage) {
        try {
            ImageProducer producer = new FilteredImageSource(sourceImage.getSource(),
                    new MyRGBImageFilter(MyRGBImageFilter.BLUE));
            return Toolkit.getDefaultToolkit().createImage(producer);
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "error", e);
        }
        return null;
    }

    /**
     * showGray
     * 
     * @param sourceImage
     * @return the grayscale image of the source
     */
    public Image showGray(Image sourceImage) {
        try {
            ImageProducer producer = new FilteredImageSource(sourceImage.getSource(),
                    new MyRGBImageFilter(MyRGBImageFilter.GRAY));
            return Toolkit.getDefaultToolkit().createImage(producer);
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "error", e);
        }
        return null;
    }
}
