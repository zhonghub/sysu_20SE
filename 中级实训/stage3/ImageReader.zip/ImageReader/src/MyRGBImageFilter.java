import java.awt.image.RGBImageFilter;

/**
 * java.awt.image.RGBImageFilter
 * 重写像素过滤器
 */
public class MyRGBImageFilter extends RGBImageFilter {

    public static final int RED = 0;
    public static final int GREEN = 1;
    public static final int BLUE = 2;
    public static final int GRAY = 3;

    private int color;

    /**
     * Constructor
     * 
     * @param color RED or GREEN or BLUE or GRAY
     */
    public MyRGBImageFilter(int color) {
        this.color = color;
        canFilterIndexColorModel = true;
    }

    /**
     * filterRGB: implement abstract method from RGBImageFilter
     * 
     * @param x
     * @param y
     * @param rgb origin color
     * @return the color of pixel after red/green/blue filtering
     */
    @Override
    public int filterRGB(int x, int y, int rgb) {
        switch (color) {
            case RED:
                return (rgb & 0xffff0000);
            case GREEN:
                return (rgb & 0xff00ff00);
            case BLUE:
                return (rgb & 0xff0000ff);
            case GRAY:
                int r = (rgb & 0x00ff0000) >> 16;
                int g = (rgb & 0x0000ff00) >> 8;
                int b = (rgb & 0x000000ff);
                int c = (int) (0.299 * r + 0.587 * g + 0.114 * b);
                return (c << 16 | c << 8 | c | 0xff000000);
            default:
                return rgb;
        }
    }
}
