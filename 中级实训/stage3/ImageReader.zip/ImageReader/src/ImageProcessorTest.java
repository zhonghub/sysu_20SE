import org.junit.Test;
import static org.junit.Assert.assertEquals;
import java.io.*;
import javax.imageio.ImageIO;
import java.awt.*;
import java.util.logging.*;

import java.awt.image.BufferedImage;
import imagereader.*;

/*
 *
 * 使用Junit进行单元测试，比较4种情况下的：
 * 两张位图（目标和结果）的位图宽度、位图高度以及像素值是否相同
 */
public class ImageProcessorTest {

	private static Logger LOGGER = Logger.getLogger(ImageProcessorTest.class.toString());
	private IImageIO imageioer;
	private IImageProcessor processor;
	private Image image1;
	private Image image2;
	private final String filePath = "./bmptest/";
	private final String logtext = "log.text";

	/*
	 * 构造函数中先得到2张测试图片的R、G、B、Gray4个结果bmp图像并保存
	 * 再分别测试R、G、B、Gray每种结果bmp图像是否与目标bmp图像相同
	 */
	public ImageProcessorTest() {
		imageioer = new ImplementImageIO();
		processor = new ImplementImageProcessor();
		try {
			image1 = imageioer.myRead(filePath + "1.bmp");
			image2 = imageioer.myRead(filePath + "2.bmp");

			imageioer.myWrite(processor.showChanelR(image1), filePath + "myResult/1_red.bmp");
			imageioer.myWrite(processor.showChanelG(image1), filePath + "myResult/1_green.bmp");
			imageioer.myWrite(processor.showChanelB(image1), filePath + "myResult/1_blue.bmp");
			imageioer.myWrite(processor.showGray(image1), filePath + "myResult/1_gray.bmp");

			imageioer.myWrite(processor.showChanelR(image2), filePath + "myResult/2_red.bmp");
			imageioer.myWrite(processor.showChanelG(image2), filePath + "myResult/2_green.bmp");
			imageioer.myWrite(processor.showChanelB(image2), filePath + "myResult/2_blue.bmp");
			imageioer.myWrite(processor.showGray(image2), filePath + "myResult/2_gray.bmp");

		} catch (IOException e) {
			LOGGER.log(Level.WARNING, "error", e);
		}
	}

	/**
	 * 比较两张位图的位图宽度、位图高度以及像素值
	 * 
	 * @return ture if two images are equal
	 **/
	public boolean isEqual(BufferedImage image1, BufferedImage image2) {
		int w1 = image1.getWidth(null);
		int h1 = image1.getHeight(null);

		int w2 = image2.getWidth(null);
		int h2 = image2.getHeight(null);

		if (w1 != w2 || h1 != h2) {
			return false;
		}

		for (int i = 0; i < w1; i++) {
			for (int j = 0; j < h1; j++) {
				if (image1.getRGB(i, j) != image2.getRGB(i, j)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Test of Chanel Red Image
	 */
	@Test
	public void testRed() {
		try {
			String goalFilePath1 = filePath + "goal/1_red_goal.bmp";
			String goalFilePath2 = filePath + "goal/2_red_goal.bmp";

			BufferedImage redImage1Goal = ImageIO.read(new FileInputStream(goalFilePath1));
			BufferedImage redImage2Goal = ImageIO.read(new FileInputStream(goalFilePath2));

			BufferedImage redImage1 = ImageIO.read(new FileInputStream(filePath + "myResult/1_red.bmp"));
			BufferedImage redImage2 = ImageIO.read(new FileInputStream(filePath + "myResult/2_red.bmp"));

			assertEquals(true, isEqual(redImage1Goal, redImage1));
			assertEquals(true, isEqual(redImage2Goal, redImage2));
			System.out.println("testRed pass!");

		} catch (IOException e) {
			LOGGER.log(Level.WARNING, "error", e);
		}
	}

	/**
	 * Test of Chanel Blue Image
	 */
	@Test
	public void testBlue() {
		try {
			String goalFilePath1 = filePath + "goal/1_blue_goal.bmp";
			String goalFilePath2 = filePath + "goal/2_blue_goal.bmp";

			BufferedImage blueImage1Goal = ImageIO.read(new FileInputStream(goalFilePath1));
			BufferedImage blueImage2Goal = ImageIO.read(new FileInputStream(goalFilePath2));

			BufferedImage blueImage1 = ImageIO.read(new FileInputStream(filePath + "myResult/1_blue.bmp"));
			BufferedImage blueImage2 = ImageIO.read(new FileInputStream(filePath + "myResult/2_blue.bmp"));

			assertEquals(true, isEqual(blueImage1Goal, blueImage1));
			assertEquals(true, isEqual(blueImage2Goal, blueImage2));
			System.out.println("testBlue pass!");

		} catch (IOException e) {
			LOGGER.log(Level.WARNING, "error", e);
		}
	}

	/**
	 * Test of Chanel Green Image
	 */
	@Test
	public void testGreen() {
		try {
			String goalFilePath1 = filePath + "goal/1_green_goal.bmp";
			String goalFilePath2 = filePath + "goal/2_green_goal.bmp";

			BufferedImage greenImage1Goal = ImageIO.read(new FileInputStream(goalFilePath1));
			BufferedImage greenImage2Goal = ImageIO.read(new FileInputStream(goalFilePath2));

			BufferedImage greenImage1 = ImageIO.read(new FileInputStream(filePath + "myResult/1_green.bmp"));
			BufferedImage greenImage2 = ImageIO.read(new FileInputStream(filePath + "myResult/2_green.bmp"));

			assertEquals(true, isEqual(greenImage1Goal, greenImage1));
			assertEquals(true, isEqual(greenImage2Goal, greenImage2));
			System.out.println("testGreen pass!");

		} catch (IOException e) {
			LOGGER.log(Level.WARNING, "error", e);
		}
	}

	/**
	 * Test of Gray Scale Image
	 */
	@Test
	public void testGray() {
		try {
			String goalFilePath1 = filePath + "goal/1_gray_goal.bmp";
			String goalFilePath2 = filePath + "goal/2_gray_goal.bmp";

			BufferedImage grayImage1Goal = ImageIO.read(new FileInputStream(goalFilePath1));
			BufferedImage grayImage2Goal = ImageIO.read(new FileInputStream(goalFilePath2));

			BufferedImage grayImage1 = ImageIO.read(new FileInputStream(filePath + "myResult/1_gray.bmp"));
			BufferedImage grayImage2 = ImageIO.read(new FileInputStream(filePath + "myResult/2_gray.bmp"));

			assertEquals(true, isEqual(grayImage1Goal, grayImage1));
			assertEquals(true, isEqual(grayImage2Goal, grayImage2));
			System.out.println("testGray pass!");

		} catch (IOException e) {
			LOGGER.log(Level.WARNING, "error", e);
		}
	}

}
