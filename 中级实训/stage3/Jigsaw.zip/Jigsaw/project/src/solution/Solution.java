package solution;

import java.util.HashSet;
import java.util.Queue;
import java.util.Random;
import java.util.LinkedList;

import jigsaw.Jigsaw;
import jigsaw.JigsawNode;

/**
 * 在此类中填充算法，完成重拼图游戏（N-数码问题）
 */
public class Solution extends Jigsaw {

    /**
     * 拼图构造函数
     */
    public Solution() {
    }

    /**
     * 拼图构造函数
     * 
     * @param bNode - 初始状态节点
     * @param eNode - 目标状态节点
     */
    public Solution(JigsawNode bNode, JigsawNode eNode) {
        super(bNode, eNode);
    }

    /**
     * （实验一）广度优先搜索算法，求指定5*5拼图（24-数码问题）的最优解
     * 填充此函数，可在Solution类中添加其他函数，属性
     * 
     * @param bNode - 初始状态节点
     * @param eNode - 目标状态节点
     * @return 搜索成功时为true,失败为false
     */
    public boolean BFSearch(JigsawNode bNode, JigsawNode eNode) {
        Queue<JigsawNode> openList = new LinkedList<JigsawNode>();
        HashSet<JigsawNode> closeList = new HashSet<JigsawNode>();
        beginJNode = new JigsawNode(bNode);
        endJNode = new JigsawNode(eNode);
        currentJNode = null;
        int searchedNodesNum = 0;
        openList.add(bNode);
        closeList.add(bNode);
        while (!openList.isEmpty()) {
            searchedNodesNum++;
            currentJNode = new JigsawNode(openList.remove());
            if (currentJNode.equals(eNode)) {
                    getPath();
                    break;
                }
            for (int i = 0; i < 4; ++i) {
                JigsawNode nowi = new JigsawNode(currentJNode);
                if (nowi.move(i)) {
                    if (!closeList.contains(nowi)&& !openList.contains(nowi)) {
                        openList.add(nowi);
                    }
                }
            }
            closeList.add(currentJNode);
        }

        System.out.println("Jigsaw BFSearch Completed");
        System.out.println("Begin state:" + getBeginJNode().toString());
        System.out.println("End state:" + getEndJNode().toString());
        System.out.println("Solution Path: ");
        System.out.println(getSolutionPath());
        System.out.println("Total number of searched nodes:" + searchedNodesNum);
        System.out.println("Length of the solution path is:" + getCurrentJNode().getNodeDepth());

        return isCompleted();
    }

    /**
     * （Demo+实验二）计算并修改状态节点jNode的代价估计值:f(n)
     * 如 f(n) = s(n). s(n)代表后续节点不正确的数码个数
     * 此函数会改变该节点的estimatedValue属性值
     * 修改此函数，可在Solution类中添加其他函数，属性
     * 
     * @param jNode - 要计算代价估计值的节点
     */
    public void estimateValue(JigsawNode jNode) {
        double s = 0;
        s += estimateValue0(jNode);
        for (int i = 0; i < 4; ++i) {
            JigsawNode nowi = new JigsawNode(jNode);
            nowi.move(i);
            s += getInCorrect(nowi);
        }
        jNode.setEstimatedValue((int) s);
    }

    /*
     * 当前节点自身的代价
     */
    public int estimateValue0(JigsawNode jNode) {
        int f = 7 * getHx(jNode) + 3 * getInCorrect(jNode);
        return f;
    }

    /*
     * 曼哈顿距离之和
     */
    private int getHx(JigsawNode jNode) {
        int[] data = jNode.getNodesState();
        int dimension = JigsawNode.getDimension();
        int h_x = 0;
        for (int i = 0; i < dimension * dimension; ++i) {
            if (data[i + 1] != 0) {
                int x1 = i % dimension;
                int y1 = i / dimension;
                int x2 = (data[i + 1] - 1) % dimension;
                int y2 = (data[i + 1] - 1) / dimension;
                int d = Math.abs(x2 - x1) + Math.abs(y2 - y1);
                h_x += d; // h(x)，曼哈顿距离
            }
        }
        return h_x;
    }

    /*
     * 不在正确位置上的数码块之和
     */
    public int getInCorrect(JigsawNode jNode) {
        int s = 0;
        int dimension = JigsawNode.getDimension();
        for (int index = 1; index < dimension * dimension; index++) {
            if (jNode.getNodesState()[index] != index) {
                s++;
            }
        }
        return s;
    }

}
