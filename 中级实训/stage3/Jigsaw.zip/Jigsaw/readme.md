## Readme.md

### 文件目录

```
 ├── Jigsaw
 │   └── project 	// 项目文件夹
 |		  └── src      // 源文件目录
 |		  └── lib      // 项目依赖jar包目录
 |		  └── build      // .class文件目录
 │   └── Solution.java 		// 我写的源码 
 ├── README.md
 
```



### 代码运行方式

见project/readme.md。