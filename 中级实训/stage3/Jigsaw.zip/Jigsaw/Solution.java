package solution;

import java.util.HashSet;
import java.util.Queue;
import java.util.Random;
import java.util.LinkedList;

import jigsaw.Jigsaw;
import jigsaw.JigsawNode;

/**
 * 在此类中填充算法，完成重拼图游戏（N-数码问题）
 */
public class Solution extends Jigsaw {

    /**
     * 拼图构造函数
     */
    public Solution() {
    }

    /**
     * 拼图构造函数
     * 
     * @param bNode - 初始状态节点
     * @param eNode - 目标状态节点
     */
    public Solution(JigsawNode bNode, JigsawNode eNode) {
        super(bNode, eNode);
    }

    /**
     * （实验一）广度优先搜索算法，求指定5*5拼图（24-数码问题）的最优解
     * 属性：
     * 使用队列作为open表，记录未访问的可达节点
     * 使用集合作为close表，记录已经访问过的可达节点，可降低查询的时间复杂度
     * 算法流程：
     * while循环每次取出队列open表的队首，再将其后继节点中未访问的可达点（不在open表和close表中的可达节点）都加入open表，
     * 之后将取出的open表的队首加入close表，
     * 最后直到：open表为空或取出的open表的队首节点为目标节点终止循环。
     * 
     * @param bNode - 初始状态节点
     * @param eNode - 目标状态节点
     * @return 搜索成功时为true,失败为false
     */
    public boolean BFSearch(JigsawNode bNode, JigsawNode eNode) {
        Queue<JigsawNode> openList = new LinkedList<JigsawNode>();
        HashSet<JigsawNode> closeList = new HashSet<JigsawNode>();
        beginJNode = new JigsawNode(bNode);
        endJNode = new JigsawNode(eNode);
        currentJNode = null;
        int searchedNodesNum = 0;
        openList.add(bNode);
        closeList.add(bNode);
        while (!openList.isEmpty()) {
            searchedNodesNum++;
            currentJNode = new JigsawNode(openList.remove());
            if (currentJNode.equals(eNode)) {
                    getPath();
                    break;
                }
            for (int i = 0; i < 4; ++i) {
                JigsawNode nowi = new JigsawNode(currentJNode);
                if (nowi.move(i)) {
                    if (!closeList.contains(nowi)&& !openList.contains(nowi)) {
                        openList.add(nowi);
                    }
                }
            }
            closeList.add(currentJNode);
        }

        System.out.println("Jigsaw BFSearch Completed");
        System.out.println("Begin state:" + getBeginJNode().toString());
        System.out.println("End state:" + getEndJNode().toString());
        System.out.println("Solution Path: ");
        System.out.println(getSolutionPath());
        System.out.println("Total number of searched nodes:" + searchedNodesNum);
        System.out.println("Length of the solution path is:" + getCurrentJNode().getNodeDepth());

        return isCompleted();
    }

    /**
     * （Demo+实验二）计算并修改状态节点jNode的代价估计值:f(n)
     * f(n) = f0(n) + s(n+1)
     * 其中f0(n)为当前节点的代价，使用estimateValue0获取
     * s(n+1) 为后续节点不在正确位置上的数码块之和
     * 要适当考虑后继节点的权重
     * 
     * @param jNode - 要计算代价估计值的节点
     */
    public void estimateValue(JigsawNode jNode) {
        double s = 0;
        s += estimateValue0(jNode);
        for (int i = 0; i < 4; ++i) {
            JigsawNode nowi = new JigsawNode(jNode);
            nowi.move(i);
            s += getInCorrect(nowi);
        }
        jNode.setEstimatedValue((int) s);
    }

    /*
     * 当前节点自身的代价：
     * f0(n) = 7*H(n) + 3*s(n)
     * H(n)为当前节点的曼哈顿距离之和
     * s(n)为当前节点的不在正确位置上的数码块之和
     * 曼哈顿距离之和的权重大一些，经过测试，欧式距离的效果不佳
     */
    public int estimateValue0(JigsawNode jNode) {
        int f = 7 * getHx(jNode) + 3 * getInCorrect(jNode);
        return f;
    }

    /*
     * 曼哈顿距离之和：dx+dy
     */
    private int getHx(JigsawNode jNode) {
        int[] data = jNode.getNodesState();
        int dimension = JigsawNode.getDimension();
        int h_x = 0;
        for (int i = 0; i < dimension * dimension; ++i) {
            if (data[i + 1] != 0) {
                int x1 = i % dimension;
                int y1 = i / dimension;
                int x2 = (data[i + 1] - 1) % dimension;
                int y2 = (data[i + 1] - 1) / dimension;
                int d = Math.abs(x2 - x1) + Math.abs(y2 - y1);
                h_x += d; // h(x)，曼哈顿距离
            }
        }
        return h_x;
    }

    /*
     * 不在正确位置上的数码块之和
     */
    public int getInCorrect(JigsawNode jNode) {
        int s = 0;
        int dimension = JigsawNode.getDimension();
        for (int index = 1; index < dimension * dimension; index++) {
            if (jNode.getNodesState()[index] != index) {
                s++;
            }
        }
        return s;
    }

}
