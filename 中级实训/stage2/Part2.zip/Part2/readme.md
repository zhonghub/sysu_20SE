### 代码运行方式

#### 在目录Part2下：

1. `CircleBug`

   

javac -classpath .:gridworld.jar CircleBug/*.java && java -classpath .:gridworld.jar:CircleBug CircleBugRunner





2. `SpiralBug`

   

javac -classpath .:gridworld.jar SpiralBug/*.java  && java -classpath .:gridworld.jar:SpiralBug SpiralBugRunner



3. `ZBug` 

   

javac -classpath .:gridworld.jar ZBug/*.java && java -classpath .:gridworld.jar:ZBug ZBugRunner



4. `DancingBug` 

   

javac -classpath .:gridworld.jar DancingBug/*.java  && java -classpath .:gridworld.jar:DancingBug DancingBugRunner