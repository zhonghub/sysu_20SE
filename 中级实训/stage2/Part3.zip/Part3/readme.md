### 代码运行方式：

将Jumper.zip解压到当且目标（Part3）下后，在当前目录下，在终端运行指令：

```
javac -classpath .:lib/* Jumper/*.java && java -classpath .:lib/*:Jumper JumperRunner
```



终端进行Junit测试：

```
ant test
```
