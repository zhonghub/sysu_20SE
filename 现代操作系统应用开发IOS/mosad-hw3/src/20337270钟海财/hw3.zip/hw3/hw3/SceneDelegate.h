//
//  SceneDelegate.h
//  hw3
//
//  Created by sushan on 2022/10/24.
//  Copyright © 2022 SYSU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

