//
//  Heroes.h
//  hw1
// 共10个英雄的子类
// Lvbu Liubei Zhangfei Zhaoyun Zhouyu Sunce Zhangliao Machao Huaxiong Guanyu

#ifndef Heroes_h
#define Heroes_h

#import "Hero.h"

@interface Heroes : NSObject{
}
@end


@interface Lvbu : Hero {
// 子类，继承基类Hero，只重写使用技能的方法(void)skills:(int)round
}
@end

@interface Liubei : Hero {
// 子类，继承基类Hero，只重写使用技能的方法(void)skills:(int)round
}
@end

@interface Zhangfei : Hero {
// 子类，继承基类Hero，只重写使用技能的方法(void)skills:(int)round
}
@end

@interface Zhaoyun : Hero {
// 子类，继承基类Hero，只重写使用技能的方法(void)skills:(int)round
}
@end

@interface Zhouyu : Hero {
// 子类，继承基类Hero，只重写使用技能的方法(void)skills:(int)round
}
@end

@interface Sunce : Hero {
// 子类，继承基类Hero，只重写使用技能的方法(void)skills:(int)round
}
@end

@interface Zhangliao : Hero {
// 子类，继承基类Hero，只重写使用技能的方法(void)skills:(int)round
}
@end

@interface Machao : Hero {
// 子类，继承基类Hero，只重写使用技能的方法(void)skills:(int)round
}
@end

@interface Huaxiong : Hero {
// 子类，继承基类Hero，只重写使用技能的方法(void)skills:(int)round
}
@end

@interface Guanyu : Hero {
// 子类，继承基类Hero，只重写使用技能的方法(void)skills:(int)round
}
@end



#endif /* Heroes_h */
