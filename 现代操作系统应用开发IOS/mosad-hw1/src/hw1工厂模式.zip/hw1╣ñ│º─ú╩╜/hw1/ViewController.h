//
//  ViewController.h
//  hw1
//
//  Created by sushan on 2022/9/6.
//  Copyright © 2022 SYSU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

